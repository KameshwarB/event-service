insert into exchange_value(id,city,price)
values(10001,'Bangalore',30);
insert into exchange_value(id,city,price)
values(10002,'Mangalore',40);
insert into exchange_value(id,city,price)
values(10003,'Mumbai',50);